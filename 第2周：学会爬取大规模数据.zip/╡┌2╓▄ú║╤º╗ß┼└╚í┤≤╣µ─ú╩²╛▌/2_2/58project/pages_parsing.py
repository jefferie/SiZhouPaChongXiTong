from bs4 import BeautifulSoup
import requests
import time
import pymongo

client = pymongo.MongoClient('localhost',27017)
ceshi = client['ceshi']
url_list = ceshi['url_list']
item_info = ceshi['item_info']

#speder 1
def get_links_from(channel,pages,who_sells=0):
    #http://bj.58.com/shouji/0/pn2/
    list_view='{}{}/pn{}'.format(channel, str(who_sells), str(pages))
    con = requests.get(list_view)
    time.sleep(1)
    soup = BeautifulSoup(con.text, 'lxml')
    if soup.find('td','t'):
        links = soup.select('td.t a.t')
        for link in links:
            item_link = link.get('href').split('?')[0]
            url_list.insert_one({'url':item_link})
            print(item_link)
    else:
        pass

# get_links_from('http://bj.58.com/shouji/', 2)

def get_item_info(url):
    con = requests.get(url)
    soup = BeautifulSoup(con.text, 'lxml')
    # no_longer_exist = '404' in soup.find('script', type="text/javascript").get('src').split('/')
    # if no_longer_exist:
    #     pass
    # else:
    title = soup.title.text.replace('       ','')
    price = soup.select('span.price_now i')[0].text.replace('       ','')
    area = soup.select('div.palce_li span i')[0].text if soup.find('div','palce_li') else None
    item_info.insert_one({'title':title, 'price':price, 'area':area})
    print({'title':title, 'price':price, 'area':area})

# url = 'http://zhuanzhuan.58.com/detail/998102490931838986z.shtml'
# get_item_info(url)

# url2 = 'http://bj.58.com/shouji/24605954621114x.shtml'
# con = requests.get(url2)
# soup = BeautifulSoup(con.text, 'lxml')
# print(soup.prettify())
