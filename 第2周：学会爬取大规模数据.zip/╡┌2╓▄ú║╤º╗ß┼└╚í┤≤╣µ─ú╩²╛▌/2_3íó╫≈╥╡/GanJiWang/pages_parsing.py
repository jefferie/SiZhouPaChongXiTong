from bs4 import BeautifulSoup
import pymongo
import requests
import time
import random

client = pymongo.MongoClient('localhost', 27017)
ganjiwang = client['ganjiwang']
url_list = ganjiwang['url_list']
item_list = ganjiwang['item_list']

headers = {
    #填上User-Agent
    'User-Agent':'',
    'Connection':'keep-alive'
}

# http://cn-proxy.com/
proxy_list = [
    'http://123.57.217.208:3128',
    'http://122.114.31.177:808'
]
proxy_ip = random.choice(proxy_list) # 随机获取代理ip
proxies = {'http': proxy_ip}

def get_links_from(channel, pages, who_sells='o'):
    #http://bj.ganji.com/jiaju/o3/
    list_view = '{}{}{}'.format(channel, str(who_sells), str(pages))
    con = requests.get(list_view, headers = headers)
    soup = BeautifulSoup(con.text, 'lxml')
    if soup.find('ul', 'pageLink'):
        links = soup.select('tr.zzinfo td.t a.t')
        for link in links:
            item_link = link.get('href').split('?')[0]
            url_list.insert_one({'url':item_link})
            print(item_link)
    else:
        pass

# get_links_from('http://bj.ganji.com/ershoubijibendiannao/', 3)

def get_item_from(url):
    con = requests.get(url, headers = headers)
    if con.status_code == 404:
        pass
    else:
        try:
            soup = BeautifulSoup(con.text, 'lxml')
            data = {
                'title': soup.select('div.box_left_top h1.info_titile')[0].get_text().replace('\xa0',''),
                'price': soup.select('div.price_li span.price_now i')[0].get_text(),
                'area': soup.select('div.palce_li span i')[0].get_text() if soup.find('div','palce_li') else None,
                'url':url
            }
            item_list.insert_one({'data':data})
            print(data)
        except AttributeError:
            pass
        except IndexError:
            pass

# get_item_from('http://zhuanzhuan.ganji.com/detail/1001710935598153734z.shtml')
