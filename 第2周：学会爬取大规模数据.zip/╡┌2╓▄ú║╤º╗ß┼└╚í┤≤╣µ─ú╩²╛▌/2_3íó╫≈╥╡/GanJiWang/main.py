from pages_parsing import get_links_from, get_item_from, url_list
from channel_extract import channel_list
from multiprocessing import Pool

def get_all_links(channel):
    for num in range(1,100):
        get_links_from(channel, num)

links_list = [item['url'] for item in url_list.find()]

if __name__ == '__main__':
    pool = Pool()
    # pool.map(get_all_links, channel_list.split())
    pool.map(get_item_from, links_list)
