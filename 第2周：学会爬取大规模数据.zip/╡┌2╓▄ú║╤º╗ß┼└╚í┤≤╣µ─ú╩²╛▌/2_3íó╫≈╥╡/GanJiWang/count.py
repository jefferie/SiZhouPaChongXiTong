import time
from pages_parsing import url_list, item_list

while True:
    # print(url_list.find().count())
    print(item_list.find().count())
    time.sleep(5)
