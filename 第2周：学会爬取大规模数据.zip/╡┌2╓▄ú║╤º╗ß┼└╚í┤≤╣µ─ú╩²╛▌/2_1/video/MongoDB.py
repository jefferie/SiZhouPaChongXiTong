import pymongo

client = pymongo.MongoClient('localhost',27017)
walden = client['walden']
sheet_tab = walden['sheet_tab']

path = 'C:/work/Web crawler/项目/四周实现爬虫系统/第2周：学会爬取大规模数据/2_1/walden.txt'
with open(path,'r') as f:
    lines = f.readlines()
    for index,line in enumerate(lines):
        data = {
            'index':index,
            'line':line,
            'words':len(line.split())
        }
        sheet_tab.insert_one(data)

for item in sheet_tab.find({'words':{'$lt':5}}):
    print(item)
