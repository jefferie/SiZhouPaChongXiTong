import requests
from bs4 import BeautifulSoup
import pymongo

client = pymongo.MongoClient('localhost',27017)
xiaozhu = client['xiaozhu']
sheet_xinxi = xiaozhu['sheet_xinxi']

# ====================================================== <<<< 单页行为 >>>> =============================================

url = 'http://bj.xiaozhu.com/search-duanzufang-p20-0/'
con = requests.get(url)
soup = BeautifulSoup(con.text, 'lxml')
titles = soup.select('span.result_title')
prices = soup.select('span.result_price > i')
for title, price in zip(titles, prices):
    data = {
        'title':title,
        'price':price
    }
    sheet_xinxi.insert_one(data)
print('Done')

# ====================================================== <<<< 设计函数 >>>> =============================================
def get_pages_within(pages):
    for page_num in range(1, pages+1):
        url = 'http://bj.xiaozhu.com/search-duanzufang-p{}-0/'.format(page_num)
        con = requests.get(url)
        soup = BeautifulSoup(con.text, 'lxml')
        titles = soup.select('span.result_title')
        prices = soup.select('span.result_price > i')
        for title, price in zip(titles, prices):
            data = {
                'title':title,
                'price':price
            }
            sheet_xinxi.insert_one(data)
    print('Done')

get_pages_within(3)

for i in sheet_xinxi.find():
    if i['price'] >= 500:
        print(i)
