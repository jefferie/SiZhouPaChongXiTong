from bs4 import BeautifulSoup
import requests
import time

url = 'https://knewone.com/discover?page='


def get_content(url,data=None):
    con = requests.get(url)
    soup = BeautifulSoup(con.text,'lxml')
    titles = soup.select('section.content > h4 > a')
    imgs = soup.select('a.cover-inner > img')
    links = soup.select('section.content > h4 > a')
    if data==None:
        for title, img, link in zip(titles,imgs,links):
            data={
                'title':title.get_text(),
                'img':img.get('src'),
                'link':link.get('href')
            }
            print(data)

def get_pages(url):
    for i in range(10):
        get_content(url+str(i))
        time.sleep(1)

get_pages(url)
