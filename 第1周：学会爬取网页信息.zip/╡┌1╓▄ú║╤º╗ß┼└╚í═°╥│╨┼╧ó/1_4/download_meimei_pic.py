import requests
from bs4 import BeautifulSoup
import time
import urllib.request

url = 'https://weheartit.com/inspirations/taylorswift?page='
# 此网站会有针对 ip 的反爬取，可以采用代理的方式
proxies = {"http": "http://182.18.13.149"}
url_page = []

def get_pic(url):
    con= requests.get(url, proxies=proxies)
    soup = BeautifulSoup(con.text, 'lxml')
    pics = soup.select('div.no-padding > div.entry-preview > a > img')

    for each in pics:
        pic_url = each.get('src')
        url_page.append(pic_url)
        print('now downloading:'+pic_url)
        path = 'C:/work/Web crawler/项目/四周实现爬虫系统/第1周：学会爬取网页信息/1_4/霉霉图片/' +str(len(url_page)) + '.jpg'
        urllib.request.urlretrieve(pic_url, path)

def get_pages(url):
    for i in range(1,6):
        get_pic(url+str(i))
        time.sleep(1)

get_pages(url)
