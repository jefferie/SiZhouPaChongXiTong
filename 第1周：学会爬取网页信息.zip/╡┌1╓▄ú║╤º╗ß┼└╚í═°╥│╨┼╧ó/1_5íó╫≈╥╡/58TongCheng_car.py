from bs4 import BeautifulSoup
import requests

# url = 'http://bj.58.com/ershouche/34216782512938x.shtml'

def get_links_from(who_sells):
    urls = []
    list_view = 'http://bj.58.com/ershouche/{}/?minprice=20_99999999&PGTID=0d30001d-0000-1c33-ec7b-a63c283320d6&ClickID=6'.format(str(who_sells))
    con = requests.get(list_view)
    soup = BeautifulSoup(con.text,'lxml')
    for link in soup.select('div.col.col2 a'):
        links = link.get('href').split('?')[0]
        urls.append(links)
    # print(urls)
    return urls


def get_item_info(who_sells=0):
    urls = get_links_from(who_sells)
    for url in urls:
        con = requests.get(url)
        soup = BeautifulSoup(con.text, 'lxml')
        data={
            'title':soup.select('p.title_p')[0].text if soup.find_all('p','title_p') else None,
            'price':soup.select('div.price span.price_span')[0]
                .text.replace('\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t','')
                .replace('\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t','') if soup.find_all('div','price') else None,
            'area':list(soup.select('div.adress')[0].stripped_strings)[1] if soup.find_all('div','adress') else None,
            'post_time' : soup.select('div.posttime span.time')[0].text.replace('  ','') if soup.find_all('div','posttime') else None,
            'cate':None,
            'views':None
        }
        print(data)

get_item_info(0)
# get_links_from()
